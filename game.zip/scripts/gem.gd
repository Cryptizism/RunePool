extends Sprite2D

var gem_color: String = "red"
var connected_gem: Node2D
var board_x: float
var board_y: float
var target_position: Vector2i
var starting_scale: float = 0
var target_scale: float = 1
var move_speed: float = 25
var pulsate: bool = false
var pulse_timer: float = 0.0
var pulse_speed: float = 2.0
var pulse_strength: float = 0.1

func _ready() -> void:
	scale = Vector2(starting_scale, starting_scale)

func _process(delta: float) -> void:
	position = position.lerp(target_position, delta * move_speed)
	scale = scale.lerp(Vector2(target_scale, target_scale), 0.2)
	if !pulsate:
		return
	pulse_timer += delta * pulse_speed
	var new_scale = 1 + sin(pulse_timer) * pulse_strength
	scale = Vector2(new_scale, new_scale)
