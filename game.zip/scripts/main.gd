extends Node2D

@onready var board_sprite: Sprite2D = $Sprite2D
var gem_scene = preload("res://scenes/gem.tscn")

const TILE_SIZE: int = 8
const WIDTH: int = 8
const HEIGHT: int = 16
const START_INTERVAL: float = 3
const FALL_INTERVAL: float = 0.5
const INPUT_INTERVAL: float = 0.1
const DROP_INTERVAL: float = 0.3
const COLOR_OPTIONS = {
	"red": "res://sprites/red.png",
	"blue": "res://sprites/blue.png",
	"green": "res://sprites/green.png",
	"yellow": "res://sprites/yellow.png",
}
const RUNE_OPTIONS = {
	"red": "res://sprites/rune_red.png",
	"blue": "res://sprites/rune_blue.png",
	"green": "res://sprites/rune_green.png",
	"yellow": "res://sprites/rune_yellow.png",
}
var color_options = COLOR_OPTIONS.duplicate(true)
var rune_options = RUNE_OPTIONS.duplicate(true)

var board: Array[Array] = []
var current_gem_cluster: Node2D
var current_gem_cluster_position: Vector2i = Vector2i(0, 0)
var current_gem_cluster_offsets: Array = [Vector2i(0, 0), Vector2i(0, 0)]
var next_color_index: int = 0
var preview_gem1: Node2D
var preview_gem2: Node2D
var start_timer: float = 0.0
var fall_timer: float = 0.0
var input_timer: float = 0.0
var drop_timer: float = 0.0

func new_game() -> void:
	randomize()
	reset_board()
	remove_random_color()
	create_runes(20, HEIGHT * 0.4)
	start_timer = 0
	randomize_preview_gems()

func _ready() -> void:
	create_preview_gems()
	new_game()

func _physics_process(delta: float) -> void:
	#handle timers
	fall_timer += delta
	input_timer += delta
	if start_timer < START_INTERVAL:
		start_timer += delta
		if start_timer >= START_INTERVAL:
			try_spawn_gem_cluster()
		return
	#handle game physics
	if drop_gems():
		return
	check_gem_lines()
	#handle controls
	if Input.is_action_pressed("move_down"):
		fall_timer += delta * 8
	if Input.is_action_just_pressed("ui_accept"):
		rotate_gem()
	if input_timer >= INPUT_INTERVAL:
		input_timer = 0
		if Input.is_action_pressed("move_left"):
			move_gem(Vector2.LEFT)
		elif Input.is_action_pressed("move_right"):
			move_gem(Vector2.RIGHT)
	#handle falling
	if fall_timer >= FALL_INTERVAL:
		fall_timer = 0
		if !move_gem(Vector2.DOWN):
			lock_gem_cluster()
			try_spawn_gem_cluster()
	if $Runes.get_child_count() <= 0:
		#VICTORY
		new_game()

func reset_board() -> void:
	board.resize(WIDTH)
	for x in range(WIDTH):
		board[x] = []
		board[x].resize(HEIGHT)
		for y in range(HEIGHT):
			board[x][y] = null
	if current_gem_cluster:
		current_gem_cluster.queue_free()
	for gem in $Gems.get_children():
		gem.queue_free()
	for rune in $Runes.get_children():
		rune.queue_free()
	color_options = COLOR_OPTIONS.duplicate(true)
	rune_options = RUNE_OPTIONS.duplicate(true)

########################################################
# gems
########################################################

func create_rune(spawn_position: Vector2i) -> void:
	var rune = gem_scene.instantiate()
	var keys = rune_options.keys()
	var color = keys[next_color_index % keys.size()]
	next_color_index += 1
	rune.connected_gem = rune
	set_gem_color(rune, color, rune_options)
	rune.position = center_in_cell(spawn_position)
	rune.target_position = rune.position
	board[spawn_position.x][spawn_position.y] = rune
	$Runes.add_child(rune)

func _create_runes_async(amount: int, vertical_gap: int) -> void:
	for i in range(amount):
		var location = get_random_cell(vertical_gap)
		if location == Vector2i(-1, -1):
			continue
		create_rune(location)
		await get_tree().create_timer(0.1).timeout

func create_runes(amount: int, vertical_gap: int) -> void:
	await _create_runes_async(amount, vertical_gap)

func copy_gem(parent_gem: Node2D) -> Node2D:
	var gem = gem_scene.instantiate()
	while (!color_options.has(parent_gem.gem_color)):
		set_gem_color(parent_gem, get_random_color(), color_options)
	set_gem_color(gem, parent_gem.gem_color, color_options)
	gem.position = center_in_cell(Vector2i(WIDTH + 2, 1))
	gem.target_position = gem.position
	current_gem_cluster.add_child(gem)
	return gem

func spawn_gem_cluster(spawn_position: Vector2i) -> void:
	if current_gem_cluster:
		current_gem_cluster.queue_free()
	current_gem_cluster = Node2D.new()
	add_child(current_gem_cluster)
	var gem1 = copy_gem(preview_gem1)
	var gem2 = copy_gem(preview_gem2)
	gem1.connected_gem = gem2
	gem2.connected_gem = gem1
	current_gem_cluster_position = spawn_position
	current_gem_cluster_offsets = [Vector2i(0, 0), Vector2i(1, 0)]
	randomize_preview_gems()
	update_gem_world_position()

func try_spawn_gem_cluster() -> void:
	var spawn_location = Vector2i(WIDTH / 2 - 1, 0)
	if is_colliding(spawn_location):
		#GAME OVER
		new_game()
		return
	spawn_gem_cluster(spawn_location)

func move_gem(direction: Vector2i) -> bool:
	for offset in current_gem_cluster_offsets:
		var next_position = current_gem_cluster_position + offset + direction
		if is_colliding(next_position):
			return false
	current_gem_cluster_position += direction
	update_gem_world_position()
	return true

func _rotation_collides(offsets: Array) -> bool:
	for offset in offsets:
		if is_colliding(current_gem_cluster_position + offset):
			return true
	return false

var rotation_map = {
	[Vector2i(0,0),Vector2i(1,0)]: [Vector2i(0,1),Vector2i(0,0)],
	[Vector2i(1,0),Vector2i(0,0)]: [Vector2i(0,0),Vector2i(0,1)],
	[Vector2i(0,0),Vector2i(0,1)]: [Vector2i(0,0),Vector2i(1,0)],
	[Vector2i(0,1),Vector2i(0,0)]: [Vector2i(1,0),Vector2i(0,0)]
}

func rotate_gem() -> void:
	var new_offsets = rotation_map.get(current_gem_cluster_offsets)
	if not new_offsets: return
	for dx in [0,-1,1]:
		current_gem_cluster_position.x += dx
		if not _rotation_collides(new_offsets):
			current_gem_cluster_offsets = new_offsets
			update_gem_world_position()
			return
		current_gem_cluster_position.x -= dx

func lock_gem_cluster() -> void:
	if !current_gem_cluster:
		return
	for gem in current_gem_cluster.get_children():
		if gem == null:
			continue
		var i = current_gem_cluster.get_children().find(gem)
		var final_position = current_gem_cluster_position + current_gem_cluster_offsets[i]
		board[final_position.x][final_position.y] = gem
	for gem in current_gem_cluster.get_children():
		gem.reparent($Gems)
	current_gem_cluster.queue_free()
	check_gem_lines()

func drop_gems() -> bool:
	var dropped_gem = false
	for x in range(WIDTH):
		for y in range(HEIGHT - 2, -1, -1):
			var gem = board[x][y]
			if !gem:
				continue
			if board[x][y + 1] != null:
				continue
			if gem == gem.connected_gem:
				continue
			if gem.connected_gem:
				var nx = gem.connected_gem.board_x
				var ny = gem.connected_gem.board_y + 1
				if ny < HEIGHT and nx >= 0 and nx < WIDTH:
					if board[nx][ny] != null and board[nx][ny] != gem:
						continue
			board[x][y + 1] = gem
			board[x][y] = null
			gem.board_y += 1
			gem.target_position = center_in_cell(Vector2i(gem.board_x, gem.board_y))
			dropped_gem = true
	return dropped_gem

func create_preview_gem(location: Vector2i) -> Node2D:
	var gem = gem_scene.instantiate()
	set_gem_color(gem, get_random_color(), color_options)
	gem.position = Vector2(location.x, location.y)
	gem.target_position = gem.position
	$Preview.add_child(gem)
	return gem

func create_preview_gems() -> void:
	if preview_gem1 and preview_gem2:
		return
	preview_gem1 = create_preview_gem(center_in_cell(Vector2i(WIDTH + 1, 1)))
	preview_gem2 = create_preview_gem(center_in_cell(Vector2i(WIDTH + 2, 1)))
	preview_gem1.connected_gem = preview_gem2
	preview_gem2.connected_gem = preview_gem1

func randomize_preview_gems() -> void:
	set_gem_color(preview_gem1, get_random_color(), color_options)
	set_gem_color(preview_gem2, get_random_color(), color_options)

########################################################
# misc
########################################################

func is_colliding(gem_position: Vector2i) -> bool:
	return (
		gem_position.x < 0
		or gem_position.x >= WIDTH
		or gem_position.y < 0
		or gem_position.y >= HEIGHT
		or board[gem_position.x][gem_position.y] != null
	)

func get_random_cell(vertical_gap: int) -> Vector2i:
	for i in 30:
		var x = randi() % WIDTH
		var y = randi() % (HEIGHT - vertical_gap)
		y += vertical_gap
		var location = Vector2i(x, y)
		if !is_colliding(location):
			return location
	return Vector2i(-1, -1)

func remove_unused_colors() -> void:
	if $Runes.get_child_count() == 0:
		return
	var remaining = {}
	for r in $Runes.get_children():
		if r.gem_color:
			remaining[r.gem_color] = true
	for color in color_options.keys():
		if not remaining.has(color):
			color_options.erase(color)
			rune_options.erase(color)
			for gem in $Gems.get_children():
				if gem.gem_color == color:
					gem.queue_free()
			randomize_preview_gems()

func remove_random_color() -> void:
	var keys = COLOR_OPTIONS.keys()
	var random = keys[randi() % keys.size()]
	color_options.erase(random)
	rune_options.erase(random)

func set_gem_color(gem: Sprite2D, gem_color: String, type) -> void:
	if !type.has(gem_color):
		return
	gem.gem_color = gem_color
	gem.texture = load(type[gem_color])

func get_random_color() -> String: return color_options.keys()[randi() % color_options.size()]
func get_random_rune() -> String: return rune_options.keys()[randi() % rune_options.size()]

func center_in_cell(cell_position: Vector2i) -> Vector2:
	@warning_ignore("integer_division")
	var location = (cell_position * TILE_SIZE) + Vector2i(TILE_SIZE/2, TILE_SIZE/2)
	return location - Vector2i(WIDTH * TILE_SIZE / 2, HEIGHT * TILE_SIZE / 2)

func update_gem_world_position() -> void:
	if !current_gem_cluster:
		return
	for i in range(current_gem_cluster.get_child_count()):
		var gem = current_gem_cluster.get_child(i)
		var new_position = current_gem_cluster_position + current_gem_cluster_offsets[i]
		gem.board_x = new_position.x
		gem.board_y = new_position.y
		gem.target_position = center_in_cell(new_position)

########################################################
# gem lines
########################################################

func get_gem_line(start: Vector2i, delta: Vector2i) -> Array:
	var line = []
	var gem = board[start.x][start.y]
	if not gem:
		return line
	var color = gem.gem_color
	var pos = start
	while pos.x >= 0 and pos.x < WIDTH and pos.y >= 0 and pos.y < HEIGHT:
		var g = board[pos.x][pos.y]
		if g and g.gem_color == color:
			line.append(pos)
		else:
			break
		pos += delta
	return line


func destroy_gem_line(start_position: Vector2i, direction: Vector2i) -> void:
	var line = get_gem_line(start_position, direction)
	if line.size() <= 3:
		return
	for gem_position in line:
		var gem = board[gem_position.x][gem_position.y]
		if !gem:
			continue
		gem.queue_free()
		board[gem_position.x][gem_position.y] = null

func destroy_gem_lines(start_position: Vector2i) -> void:
	destroy_gem_line(start_position, Vector2i(0, -1))
	destroy_gem_line(start_position, Vector2i(0, 1))
	destroy_gem_line(start_position, Vector2i(1, 0))
	destroy_gem_line(start_position, Vector2i(-1, 0))

func check_gem_lines() -> void:
	for x in range(WIDTH):
		for y in range(HEIGHT):
			var gem = board[x][y]
			var start_position = Vector2i(x, y)
			if gem == null:
				continue
			destroy_gem_lines(start_position)
			drop_gems()
